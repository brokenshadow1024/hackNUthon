from flask import Flask, render_template, request, jsonify
import pandas as pd
import csv
import os
import datetime

app = Flask(__name__)

@app.route('/')
def index():
    # Read the CSV file
    df = pd.read_csv('car data.csv')  # Replace 'data.csv' with your file
    table_html = df.to_html(classes='table table-striped', index=False)  # Convert to HTML table
    return render_template('admin.html', table=table_html)

@app.route('/add_transaction', methods=['POST'])
def add_transaction():
    try:
        user_id = request.form['user_id']
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        amount = request.form['amount']
        latitude = request.form['latitude']
        longitude = request.form['longitude']
        device_id = request.form['device_id']
        ip_address = request.form['ip_address']
        country = request.form['country']
        city = request.form['city']
        
        file_exists = os.path.exists(TRANSACTION_HISTORY_FILE)
        with open(TRANSACTION_HISTORY_FILE, mode='a', newline='') as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(["user_id", "timestamp", "amount", "latitude", "longitude", "device_id", "ip_address", "country", "city"])
            writer.writerow([user_id, timestamp, amount, latitude, longitude, device_id, ip_address, country, city])

        return jsonify({"success": True, "message": "Transaction added successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})

if __name__ == '__main__':
    app.run(debug=True)